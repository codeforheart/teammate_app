export const setDefects = (payload) =>({type:'setDefects',payload})
export const setCriticalCounter = (payload) =>({type:'setCriticalCounter',payload})
export const setServeCounter = (payload) => ({ type: 'setServeCounter',payload})